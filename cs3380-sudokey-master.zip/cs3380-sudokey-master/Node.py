# class that will store which cell is being changed and its previous value
#Leopold Marx, Quoc Than, Gavin Broussard

class Node():
    def __init__(self,PrevValue, x, y):
        self.PrevValue = PrevValue
        self.x = x
        self.y = y


